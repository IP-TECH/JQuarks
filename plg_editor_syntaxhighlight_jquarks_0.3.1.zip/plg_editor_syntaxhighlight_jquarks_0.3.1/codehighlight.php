<?php
/**
 * Editor Codehighlight Button
 * 
 * @version		$Id: codehighlight.php 59 2010-03-02 08:40:27Z fnaccache $
 * @author		IP-Tech Labs <labs@iptech-offshore.com> 
 * @copyright	2009-2010 IP-Tech
 * @package		JQuarks-Plugin
 * @subpackage	Editors-xtd
 * @link		http://www.iptechinside.com/labs/projects/show/jquarks
 * @since		0.1
 * @license     GNU/GPL2
 *    
 *    This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; version 2
 *  of the License.
 *
 *    This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA. 
 *  or see <http://www.gnu.org/licenses/>
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class plgButtonCodehighlight extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param 	object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgButtonCodehighlight(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}

	/**
	 * @desc add Code highlight button to any TinyMCE instance in component com_jquarks
	 * @return a button for highlighting the selected code 
	 */
	function onDisplay($name)
	{
		$mainframe =& JFactory::getApplication();

		// checking if we are within JQuarks
		$uri = JURI::getInstance() ;
		if ($uri->getVar('option') == 'com_jquarks') 
		{
			JHTML::_('behavior.modal');
			$link = 'index.php?option=com_jquarks&amp;controller=question&amp;task=insertCodeHighlight&amp;tmpl=component&amp;e_name='.$name;
			
			$button = new JObject();
			$button->set('modal', true);
			$button->set('text', JText::_('Code_HIGHLIGHTING'));
			$button->set('name', 'codehighlight');
			$button->set('link', $link);
			$button->set('options', "{handler: 'iframe', size: {x: 400, y: 75}}");
			$button->set('url', '../j_button2_blank.png');
	
			return $button;
		}
	}
	
}
