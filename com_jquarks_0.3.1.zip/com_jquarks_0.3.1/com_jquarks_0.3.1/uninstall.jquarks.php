<?php
	$site = JURI::root() ;
?>
<h1>Thank You for using JQuarks</h1>
<p>	
	<strong>JQuarks is provided by <a href="http://www.iptechinside.com/labs/projects/show/jquarks" title="IP-Tech">IP-Tech</a></strong>
</p>