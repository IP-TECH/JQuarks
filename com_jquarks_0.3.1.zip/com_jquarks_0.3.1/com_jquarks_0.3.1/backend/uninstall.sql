-- Droping all tables

DROP TABLE IF EXISTS `#__jquarks_quizzes_answersessions` ;
DROP TABLE IF EXISTS `#__jquarks_sessionwho` ;
DROP TABLE IF EXISTS `#__jquarks_quizsession` ;
DROP TABLE IF EXISTS `#__jquarks_users_quizzes` ;
DROP TABLE IF EXISTS `#__jquarks_quizzes_setsofquestions` ;
DROP TABLE IF EXISTS `#__jquarks_quizzes` ;
DROP TABLE IF EXISTS `#__jquarks_setsofquestions_questions` ;
DROP TABLE IF EXISTS `#__jquarks_customsets` ;
DROP TABLE IF EXISTS `#__jquarks_randomsets` ;
DROP TABLE IF EXISTS `#__jquarks_setsofquestions` ;
DROP TABLE IF EXISTS `#__jquarks_propositions` ;
DROP TABLE IF EXISTS `#__jquarks_questions` ;
DROP TABLE IF EXISTS `#__jquarks_categories` ;
DROP TABLE IF EXISTS `#__jquarks_types` ;
DROP TABLE IF EXISTS `#__jquarks_users_profiles` ;
DROP TABLE IF EXISTS `#__jquarks_profiles` ;